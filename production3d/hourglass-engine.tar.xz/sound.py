import numpy as np, wave, json, pathlib
from scipy.signal import butter,sosfilt
P=pathlib.Path(__file__).parent;T=json.loads((P/'timing.json').read_text());D=T['duration'];sr=48000;N=round(D*sr);rng=np.random.default_rng(84);mix=np.zeros((N,2))
def add(st,d,fn,g=1,pan=0):
 a=round(st*sr);b=min(N,a+round(d*sr));x=np.arange(b-a)/sr
 if len(x)==0:return
 v=fn(x)*g;mix[a:b,0]+=v*np.sqrt((1-pan)/2);mix[a:b,1]+=v*np.sqrt((1+pan)/2)
def env(x,d,a=.025,r=.15):return np.minimum(1,x/a)*np.minimum(1,np.maximum(0,(d-x)/r))
def noise(x,l,h):return sosfilt(butter(2,[l,h],btype='bandpass',fs=sr,output='sos'),rng.standard_normal(len(x)))
def chord(st,d,notes,g):
 add(st,d,lambda x:sum((np.sin(2*np.pi*f*x)+.22*np.sin(2*np.pi*2*f*x+.2*np.sin(2*np.pi*.4*x))) for f in notes)/len(notes)*env(x,d,.35,.55),g)
def pluck(st,f,g=.045,pan=0):add(st,.75,lambda x:(np.sin(2*np.pi*f*x)+.32*np.sin(2*np.pi*2*f*x)+.14*np.sin(2*np.pi*3*f*x))*np.exp(-5.4*x)*np.minimum(1,x/.015),g,pan)
def whoosh(st,d=.55,g=.11,pan=0):add(st,d,lambda x:noise(x,180,6800)*np.sin(np.pi*x/d)**1.8*(.6+.4*x/d),g,pan)
def thump(st,g=.12,pan=0):add(st,.35,lambda x:(np.sin(2*np.pi*(95*x-75*x*x))+.65*noise(x,100,2200))*np.exp(-13*x)*np.minimum(1,x/.005),g,pan)
# Wonder / lively town music, minor action ostinato, warm closing.
for i,st in enumerate(np.arange(0,20,2.5)):
 notes=[[130.81,164.81,196],[110,130.81,164.81],[146.83,174.61,220],[98,123.47,146.83]][i%4];chord(st,2.8,notes,.055)
for i,st in enumerate(np.arange(.08,19.8,.47)):
 f=[392,523.25,659.25,587.33,440,523.25,349.23,440][i%8];pluck(st,f,.034,(-1)**i*.45)
for i,st in enumerate(np.arange(20,37.5,1.65)):
 notes=[[65.41,98,130.81],[58.27,87.31,116.54],[73.42,110,146.83],[55,82.41,110]][i%4];chord(st,1.95,notes,.075)
for i,st in enumerate(np.arange(20.1,37.7,.32)):
 pluck(st,[196,261.63,233.08,196][i%4],.025,(-1)**i*.3)
 if i%2==0:thump(st,.038)
chord(37.8,4.45,[130.81,164.81,196,261.63],.09)
for i,st in enumerate(np.arange(38,41.7,.56)):pluck(st,[523.25,659.25,783.99,659.25,523.25,392,523.25][i%7],.04,(-1)**i*.35)
# Localized ambiance and clockwork ticks.
add(0,8.55,lambda x:noise(x,250,4300)*env(x,8.55,.3,.6),.025)
for st in np.arange(8.8,12.4,.47):add(st,.12,lambda x:(np.sin(2*np.pi*1100*x)+.4*noise(x,450,4200))*np.exp(-30*x),.045,.25)
whoosh(9.2,1.05,.18);whoosh(10.7,1.3,.15,-.35);thump(12.33,.16)
# Warning bell and many pan-separated footsteps.
for st in [12.7,13.2,13.7]:add(st,1.3,lambda x:(np.sin(2*np.pi*660*x)+.48*np.sin(2*np.pi*932*x)+.31*np.sin(2*np.pi*1320*x))*np.exp(-3.8*x)*np.minimum(1,x/.005),.13,-.2)
for i,st in enumerate(np.arange(13.65,16.05,.20)):thump(st,.06,(-1)**i*.45)
# Dragon wings and growl, not human speech.
for st in [16.65,17.6,18.55,19.5]:whoosh(st,.75,.14,.35)
add(16.9,1.6,lambda x:(np.sin(2*np.pi*58*x+.7*np.sin(2*np.pi*12*x))+.6*noise(x,60,500))*env(x,1.6,.3,.5),.09,.35)
for i,st in enumerate(np.arange(20.3,23.6,.34)):thump(st,.055,(-1)**i*.25)
thump(21.4,.19,.15);add(21.45,.35,lambda x:noise(x,600,5600)*np.exp(-15*x),.10,.2);whoosh(21.65,.42,.10)
# Glass turn and sand particles become a rumble; dramatic impacts.
whoosh(23.75,.85,.16);add(23.8,3.15,lambda x:noise(x,45,400)*env(x,3.15,.25,.4),.11)
add(26.5,11.0,lambda x:noise(x,150,6000)*env(x,11,.6,1.3),.055)
for st in [27.2,28.8,30.15]:thump(st,.11)
whoosh(30.65,.75,.17,.3);thump(31.65,.22)
for st in [31.75,31.86,31.99,32.14]:add(st,.48,lambda x:(noise(x,1600,10000)+.4*np.sin(2*np.pi*2170*x))*np.exp(-12*x)*np.minimum(1,x/.002),.11,.25)
whoosh(33.9,1.3,.18,.3);whoosh(35.5,1.15,.12,-.3);thump(37.2,.21);add(36.7,1.4,lambda x:noise(x,65,1600)*env(x,1.4,.08,.65),.12)
# Edit transitions are subtle, not every cut receives a loud effect.
for st in [4.05,8.55,16.1,20.07,27.02,30.59,38.05]:whoosh(max(0,st-.17),.36,.055)
peak=np.max(np.abs(mix));print('sound design peak',peak)
with wave.open(str(P/'sound.wav'),'wb') as w:w.setparams((2,2,sr,0,'NONE','not compressed'));w.writeframes((np.clip(mix,-.95,.95)*32767).astype('<i2').tobytes())
