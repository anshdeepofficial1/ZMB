import os,sys,math,json,random,subprocess,pathlib,time
os.environ.setdefault('LP_NUM_THREADS','4')
import vtk,numpy as np
from vtk.util.numpy_support import vtk_to_numpy
from PIL import Image,ImageDraw,ImageFont
P=pathlib.Path(__file__).parent; T=json.loads((P/'timing.json').read_text()); S=T['scenes']; words=T['words']; W,H=720,1280; FPS=24
r=vtk.vtkRenderer();r.SetBackground(.69,.85,.98);r.SetBackground2(.24,.60,.90);r.GradientBackgroundOn();r.AutomaticLightCreationOff()
w=vtk.vtkEGLRenderWindow();w.SetOffScreenRendering(1);w.SetSize(W,H);w.SetMultiSamples(0);w.AddRenderer(r)
for pos,color,intensity in [((-7,-10,15),(1,.90,.75),1.08),((8,1,8),(.68,.83,1),.65),((1,9,9),(1,.89,.64),.42)]:
 l=vtk.vtkLight();l.SetLightTypeToSceneLight();l.SetPosition(*pos);l.SetFocalPoint(0,0,1);l.SetColor(*color);l.SetIntensity(intensity);r.AddLight(l)
def mesh(verts,faces):
 pts=vtk.vtkPoints();[pts.InsertNextPoint(*p) for p in verts]; cells=vtk.vtkCellArray()
 for face in faces:
  cells.InsertNextCell(len(face));[cells.InsertCellPoint(int(i)) for i in face]
 poly=vtk.vtkPolyData();poly.SetPoints(pts);poly.SetPolys(cells); n=vtk.vtkPolyDataNormals();n.SetInputData(poly);n.ConsistencyOn();n.AutoOrientNormalsOn();n.SplittingOff();n.Update();return n.GetOutput()
def beveled():
 # Rounded unit cube: tessellated face patches with normals, bevel radius 0.10
 vals=[-.5,-.48,-.45,-.40,.40,.45,.48,.5]; verts=[];faces=[]; lookup={}
 for axis in range(3):
  for sign in (-1,1):
   ids=[]
   for u in vals:
    line=[]
    for v in vals:
     p=np.zeros(3);p[axis]=sign*.5;p[(axis+1)%3]=u;p[(axis+2)%3]=v; c=np.clip(p,-.40,.40);d=p-c;p=c+.10*d/np.linalg.norm(d);key=tuple(np.round(p,6));
     if key not in lookup:lookup[key]=len(verts);verts.append(p)
     line.append(lookup[key])
    ids.append(line)
   for i in range(len(vals)-1):
    for j in range(len(vals)-1):faces.append([ids[i][j],ids[i+1][j],ids[i+1][j+1],ids[i][j+1]])
 return mesh(verts,faces)
def lathe():
 # Unit-height classic rounded cylindrical toy head.
 rings=[(-.5,0),(-.5,.31),(-.48,.41),(-.43,.48),(-.34,.5),(.34,.5),(.43,.48),(.48,.41),(.5,.31),(.5,0)];N=32;verts=[];faces=[]
 for z,rad in rings:
  for j in range(N):a=2*math.pi*j/N;verts.append((rad*math.cos(a),rad*math.sin(a),z))
 for i in range(len(rings)-1):
  for j in range(N):faces.append([i*N+j,i*N+(j+1)%N,(i+1)*N+(j+1)%N,(i+1)*N+j])
 return mesh(verts,faces)
def mapper(poly):m=vtk.vtkPolyDataMapper();m.SetInputData(poly);return m
cube=vtk.vtkCubeSource();cube.Update(); sphere=vtk.vtkSphereSource();sphere.SetRadius(.5);sphere.SetThetaResolution(18);sphere.SetPhiResolution(12);sphere.Update();
MAP={'box':mapper(cube.GetOutput()),'round':mapper(beveled()),'head':mapper(lathe()),'ball':mapper(sphere.GetOutput())}
def rgb(c):
 if isinstance(c,str):return tuple(int(c[i:i+2],16)/255 for i in (0,2,4))
 return c
def actor(shape,color,opacity=1,flat=False):
 a=vtk.vtkActor();a.SetMapper(MAP[shape]);p=a.GetProperty();p.SetColor(*rgb(color));p.SetAmbient(.42 if not flat else .8);p.SetDiffuse(.76 if not flat else .2);p.SetSpecular(.13 if not flat else 0);p.SetSpecularPower(25);p.SetOpacity(opacity);r.AddActor(a);return a
# Matrices, positions use z-up, forward is -y.
def tr(x,y,z):m=np.eye(4);m[:3,3]=[x,y,z];return m
def scale(x,y,z):return np.diag([x,y,z,1])
def rx(a):a=math.radians(a);c,s=math.cos(a),math.sin(a);return np.array([[1,0,0,0],[0,c,-s,0],[0,s,c,0],[0,0,0,1]])
def ry(a):a=math.radians(a);c,s=math.cos(a),math.sin(a);return np.array([[c,0,s,0],[0,1,0,0],[-s,0,c,0],[0,0,0,1]])
def rz(a):a=math.radians(a);c,s=math.cos(a),math.sin(a);return np.array([[c,-s,0,0],[s,c,0,0],[0,0,1,0],[0,0,0,1]])
def apply(a,m):
 v=vtk.vtkMatrix4x4();v.DeepCopy(m.ravel());a.SetUserMatrix(v)
def obj(shape,pos,size,color,rotation=0,opacity=1,flat=False):
 a=actor(shape,color,opacity,flat);apply(a,tr(*pos)@rz(rotation)@scale(*size));return a
# Characters: jointed block toy rigs with separate limbs, rounded head, eyes, mouth, brows, hair and costume detailing.
class Char:
 def __init__(self,skin,shirt,pants,hair='48352e',zombie=False):
  self.parts=[];self.zombie=zombie;self.skin=skin
  def p(g,sh,xyz,sz,c,rot=None):
   a=actor(sh,c);self.parts.append((g,a,tr(*xyz)@(rot if rot is not None else np.eye(4))@scale(*sz)));return a
  p('body','round',(0,0,1.39),(.91,.50,.83),shirt)
  p('body','round',(0,0,.98),(.89,.49,.14),pants)
  # collar, center seam, and hoodie drawstrings / shirt details
  p('body','round',(0,-.254,1.67),(.32,.027,.20),'d1c1a0' if zombie else 'f2e1bc')
  p('body','round',(0,-.27,1.30),(.05,.04,.52),'395c64' if zombie else 'b66938')
  for xx in [-.15,.15]:p('body','round',(xx,-.27,1.55),(.035,.04,.23),'e3d3b3')
  if zombie:
   p('body','box',(.28,-.259,1.27),(.21,.025,.20),'243e44');p('body','box',(-.25,-.259,1.12),(.17,.025,.12),'718c7b')
  else:p('body','round',(0,-.265,1.09),(.52,.03,.15),'cf763f')
  for g,sg in [('la',-1),('ra',1)]:
   p(g,'round',(0,0,-.31),(.34,.42,.65),shirt);p(g,'round',(0,0,-.70),(.35,.40,.27),skin)
   p(g,'round',(0,0,-.51),(.35,.43,.07),'324f56' if zombie else 'd58849')
  for g,sg in [('ll',-1),('rl',1)]:
   p(g,'round',(0,0,-.36),(.40,.46,.70),pants);p(g,'round',(0,-.06,-.74),(.43,.59,.24),'2c3036');p(g,'round',(0,-.07,-.84),(.44,.59,.065),'e5dfd1' if not zombie else '6a716b')
  p('head','head',(0,0,0),(.73,.68,.69),skin)
  # Face geometry, front of head. black eyes, white highlights, eyebrows and curved smile.
  self.eyes=[];self.mouth=[]
  for xx in [-.145,.145]:
   self.eyes.append(p('head','ball',(xx,-.323,.065),(.105,.032,.15),'1d2021'))
   p('head','ball',(xx-.018,-.341,.105),(.029,.012,.029),'ffffff')
   p('head','round',(xx,-.326,.188),(.14,.026,.038),'263229' if zombie else '48352e',ry(-12 if xx<0 else 12))
  for j in range(13):
   x=-.12+j*.02;z=-.132+(.044*(abs(x)/.12)**1.6 if not zombie else -.008*(abs(x)/.12)); self.mouth.append(p('head','ball',(x,-.337,z),(.037,.026,.035),'272629'))
  self.fear=p('head','ball',(0,-.344,-.113),(.115,.032,.13),'272629')
  if zombie:
   for x,z in [(-.25,-.05),(.25,.19),(.22,-.17)]:p('head','round',(x,-.29,z),(.075,.035,.032),'527e46')
   p('head','head',(0,.014,.30),(.75,.70,.17),hair);p('head','round',(-.10,-.12,.37),(.37,.38,.13),hair,ry(-10))
  else:
   p('head','head',(0,.02,.29),(.77,.73,.22),hair)
   for j,(x,y,z) in enumerate([(-.23,-.15,.36),(-.06,-.20,.42),(.15,-.16,.38),(.28,-.04,.30)]):p('head','round',(x,y,z),(.24,.39,.18),hair,ry(-18+12*j))
  self.shadow=obj('ball',(0,0,.022),(1.3,.82,.018),'252c2d',opacity=.27,flat=True)
 def pose(self,x,y,yaw=0,walk=0,t=0,arms=None,lean=0,headturn=0,headtilt=0,duck=0,visible=True,afraid=False):
  for g,a,m in self.parts:a.SetVisibility(visible)
  self.shadow.SetVisibility(visible)
  if not visible:return
  bob=abs(math.sin(t*9))*.07*min(1,abs(walk));root=tr(x,y,bob-duck)@rz(yaw)@rx(lean)
  swing=math.sin(t*10)*35*walk; arms=arms if arms is not None else (swing,-swing);base={'body':root,'head':root@tr(0,0,2.12)@rz(headturn)@ry(headtilt),'la':root@tr(-.63,0,1.82)@rx(arms[0]),'ra':root@tr(.63,0,1.82)@rx(arms[1]),'ll':root@tr(-.23,0,.92)@rx(-swing),'rl':root@tr(.23,0,.92)@rx(swing)}
  for g,a,m in self.parts:apply(a,base[g]@m)
  self.fear.SetVisibility(afraid)
  for a in self.mouth:a.SetVisibility(not afraid)
  apply(self.shadow,tr(x,y,.026)@scale(1.35,.85,.02));self.base=base
 def shush(self):
  # Move right arm into a bent, hand-to-mouth gesture via an explicit rigid arm transform.
  shoulder=np.array([.63,0,1.82]);target=np.array([.03,-.46,1.88]);delta=target-shoulder;z=-delta/np.linalg.norm(delta);x=np.cross([0,0,1],z);x=x/np.linalg.norm(x);y=np.cross(z,x); rot=np.eye(4);rot[:3,:3]=np.column_stack([x,y,z]);b=self.base['body']@tr(*shoulder)@rot
  for g,a,m in self.parts:
   if g=='ra':apply(a,b@m)
  self.base['ra']=b
  # Index finger visibly crosses mouth; other hand remains holding the flashlight.
 def hand(self,g):return (self.base[g]@np.array([0,0,-.72,1]))[:3]
random.seed(19)
roof=mesh([(-.5,-.5,0),(.5,-.5,0),(.5,.5,0),(-.5,.5,0),(0,-.5,1),(0,.5,1)],[[0,3,2,1],[0,1,4],[3,5,2],[0,4,5,3],[1,2,5,4]]);MAP['roof']=mapper(roof)
cyl=vtk.vtkCylinderSource();cyl.SetRadius(.5);cyl.SetHeight(1);cyl.SetResolution(48);cyl.Update();tf=vtk.vtkTransform();tf.RotateX(90);fp=vtk.vtkTransformPolyDataFilter();fp.SetTransform(tf);fp.SetInputData(cyl.GetOutput());fp.Update();MAP['cyl']=mapper(fp.GetOutput());co=vtk.vtkConeSource();co.SetDirection(0,0,1);co.SetRadius(.5);co.SetHeight(1);co.SetResolution(24);co.Update();MAP['cone']=mapper(co.GetOutput())
def radial(rings,n=64):
 v=[(rad*math.cos(2*math.pi*j/n),rad*math.sin(2*math.pi*j/n),z) for z,rad in rings for j in range(n)];f=[[i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j] for i in range(len(rings)-1) for j in range(n)];return mesh(v,f)
def line(points,c,rad=.05):
 p=vtk.vtkPoints();cells=vtk.vtkCellArray();cells.InsertNextCell(len(points))
 for i,x in enumerate(points):p.InsertNextPoint(*x);cells.InsertCellPoint(i)
 poly=vtk.vtkPolyData();poly.SetPoints(p);poly.SetLines(cells);tube=vtk.vtkTubeFilter();tube.SetInputData(poly);tube.SetRadius(rad);tube.SetNumberOfSides(7);tube.Update();a=vtk.vtkActor();a.SetMapper(mapper(tube.GetOutput()));a.GetProperty().SetColor(*rgb(c));a.GetProperty().SetAmbient(.75);r.AddActor(a);return a
world=[];glass=[];outside=[];top=[];pile=[];dragon=[];wl=[];wr=[];tail=[];paw=[];bag=[];bell=[];crack=[]
def part(g,sh,p,s,c,rot=None,op=1):
 a=actor(sh,c,op);g.append((a,tr(*p)@(rot if rot is not None else np.eye(4))@scale(*s)));return a
def show(g,v=True,m=None):
 if m is None:m=np.eye(4)
 for a,b in g:a.SetVisibility(v);apply(a,m@b)
def ring(g,rad,z,c,width=.1):g.append((line([(rad*math.cos(i*math.tau/96),rad*math.sin(i*math.tau/96),z) for i in range(97)],c,width),np.eye(4)))
profile=[(-.6,8.7),(0,9),(2.5,8.7),(5,7.7),(7.6,5.7),(10.3,2.7),(12,1),(13,1),(14.7,2.7),(17.4,5.7),(20,7.7),(22.5,8.7),(25,9),(25.6,8.7)]
MAP['glass']=mapper(radial(profile));ga=part(glass,'glass',(0,0,0),(1,1,1),'b9e9f6',op=.13);ga.GetProperty().SetSpecular(.85);ga.GetProperty().SetSpecularPower(55)
# Curved translucent surface reflection ribbons.
for az,width,opacity in [(248,10,.19),(263,3,.30),(306,7,.14),(318,2,.23)]:
 vv=[]; ff=[]
 for z,rad in profile:
  for deg in (az-width/2,az+width/2):
   a=math.radians(deg);vv.append(((rad+.025)*math.cos(a),(rad+.025)*math.sin(a),z))
 for i in range(len(profile)-1):ff.append([2*i,2*i+1,2*i+3,2*i+2])
 key=f'reflection{az}';MAP[key]=mapper(mesh(vv,ff));ra=part(glass,key,(0,0,0),(1,1,1),'f2fbff',op=opacity);ra.GetProperty().LightingOff()

for z,rad in [(-.6,8.7),(25.6,8.7),(12,1),(13,1)]:ring(glass,rad,z,'e4f6f4',.11)
for th in [30,110,185,260,325]:glass.append((line([(rad*math.cos(math.radians(th)),rad*math.sin(math.radians(th)),z) for z,rad in profile],'b8e2e9',.07),np.eye(4)))
for z in [-1.1,26.1]:
 part(glass,'cyl',(0,0,z),(19,19,.85),'685237');part(glass,'cyl',(0,0,z+.26),(18.5,18.5,.35),'dfaa51');ring(glass,9.4,z,'f6d28a',.14)
for x in [-9.6,9.6]:part(glass,'cyl',(x,0,12.5),(.55,.55,27),'b08045');part(glass,'ball',(x,0,12.5),(1.6,1.6,1.6),'f1bd63')
part(outside,'box',(0,0,-2.3),(100,110,.4),'719f78');part(outside,'cyl',(0,0,-1.85),(24,24,.5),'748780');part(outside,'cyl',(0,0,-1.50),(21,21,.3),'a2a99b')
for x,y,s in [(-20,12,9),(19,16,8),(-28,2,12),(25,4,11),(-15,24,10)]:part(outside,'cone',(x,y,s/2-2),(s*1.1,s*.95,s),'829d86')
for x,y in [(-17,-1),(-14,10),(14,12),(23,-3),(-26,-8),(-18,-16),(16,-17)]:
 part(outside,'cyl',(x,y,-.4),(.65,.65,3.3),'786045');part(outside,'cone',(x,y,2.1),(4.2,4.2,4.8),'437d66');part(outside,'cone',(x,y,3.75),(3.3,3.3,3.7),'5a9d72')
part(world,'cyl',(0,0,-.17),(16.7,16.7,.34),'94b97a');part(world,'cyl',(0,0,.02),(8.8,8.8,.10),'c2b7a5');part(world,'box',(0,0,.04),(3.6,15,.10),'c2b7a5')
for i in range(-3,4):
 for j in range(-3,4):
  if i*i+j*j<16:part(world,'round',(i*.98,j*.98,.105),(.91,.91,.035),['b8b3a8','c8bfb1','d5cabc'][(i+j)%3])
def house(x,y,c,rc):
 root=tr(x,y,0)@rz(math.degrees(math.atan2(-x,y)))
 def h(sh,p,s,col):a=actor(sh,col);world.append((a,root@tr(*p)@scale(*s)))
 h('box',(0,0,1.15),(2.5,2,2.3),c);h('roof',(0,0,2.3),(2.8,2.25,.95),rc);h('box',(0,-1.02,.62),(.62,.12,1.24),'654e41');h('box',(0,-1.1,.07),(.8,.35,.12),'a9a08c')
 for xx in [-.75,.75]:
  h('box',(xx,-1.025,1.48),(.54,.09,.59),'f1e0bd');h('box',(xx,-1.08,1.48),(.42,.035,.46),'6f9aaa');h('box',(xx,-1.102,1.48),(.045,.015,.46),'f0e7c9');h('box',(xx,-1.102,1.48),(.42,.015,.045),'f0e7c9')
 h('box',(.78,.45,2.75),(.35,.42,.7),'9c6551')
for x,y,c,rc in [(-5.4,1.3,'dfba8d','9a5c47'),(5.4,1.5,'d0c2ad','657a81'),(-3.5,5.4,'b3cebf','587c68'),(3.5,5.3,'e4c8a7','a16c49'),(-5.5,-3.4,'d6a499','886276'),(5.5,-3.4,'e4d4ad','7d7867')]:house(x,y,c,rc)
for x,y,c in [(-3.2,-1.8,'c85e51'),(3.2,-1.8,'568da7'),(-3.2,2.5,'ddb459')]:
 part(world,'box',(x,y,.62),(1.55,.8,1.1),'8d674b');part(world,'box',(x,y,1.21),(1.75,1,.18),'c79e6e')
 for dx in [-.72,.72]:
  for dy in [-.36,.36]:part(world,'box',(x+dx,y+dy,1.55),(.11,.11,2.3),'795740')
 for i in range(6):part(world,'box',(x-.75+i*.3,y,2.45),(.3,1.3,.12),c if i%2==0 else 'f2e3bd')
 for i in range(4):part(world,'ball',(x-.5+i*.32,y-.22,1.43),(.28,.28,.28),['c15442','e4af44','78a950','b96c46'][i])
part(world,'box',(0,6.05,1.15),(3.5,2,2.3),'82959b');part(world,'roof',(0,6.05,2.3),(3.8,2.3,.8),'5c727b');part(world,'round',(0,5.025,1),(1.75,.09,1.95),'293e4a')
for x in [-1.55,1.55]:
 for z in [.3,.9,1.5,2.1]:part(world,'box',(x,5,z),(.5,.14,.45),'a3b0ae')
def text3(g,txt,p,s,c):
 v=vtk.vtkVectorText();v.SetText(txt);m=vtk.vtkPolyDataMapper();m.SetInputConnection(v.GetOutputPort());a=vtk.vtkActor();a.SetMapper(m);a.GetProperty().SetColor(*rgb(c));a.GetProperty().LightingOff();r.AddActor(a);g.append((a,tr(*p)@rx(90)@scale(s,s,s)))
part(world,'box',(0,4.99,2.45),(2.2,.13,.45),'4c686f');text3(world,'SHELTER',(-.87,4.91,2.35),.31,'ffffff')
part(world,'box',(-2.0,4.1,1.95),(1.05,1.05,3.9),'d4b08b');part(world,'roof',(-2.0,4.1,3.9),(1.5,1.5,.8),'a46846')
part(bell,'cone',(0,0,0),(.9,.9,.88),'e6ae4f',ry(180));part(bell,'cyl',(0,0,-.39),(.98,.98,.1),'edc66c');part(bell,'ball',(0,0,-.52),(.21,.21,.22),'8a5b32')
for x,y in [(-5.4,3.9),(5.9,4.3),(-7,-.2),(7,-.3)]:part(world,'cyl',(x,y,.75),(.24,.24,1.5),'775940');part(world,'ball',(x,y,1.83),(1.3,1.3,1.5),'76a45e')
MAP['sandmass']=mapper(radial([(18,4),(19.1,6.3),(21.7,8.1),(24.5,8.55),(24.5,0)]));part(top,'sandmass',(0,0,0),(1,1,1),'d9b269');part(pile,'cone',(0,0,0),(12.9,12.9,2),'dbb36f')
pts=vtk.vtkPoints();verts=vtk.vtkCellArray();N=3200;rng=np.random.default_rng(70);gr=rng.random((N,3))
for i in range(N):pts.InsertNextPoint(0,0,0);verts.InsertNextCell(1);verts.InsertCellPoint(i)
poly=vtk.vtkPolyData();poly.SetPoints(pts);poly.SetVerts(verts);sand=vtk.vtkActor();sand.SetMapper(mapper(poly));sand.GetProperty().SetColor(*rgb('f5cb75'));sand.GetProperty().SetPointSize(2.7);sand.GetProperty().LightingOff();r.AddActor(sand)
def falling(t,strength=1):
 elapsed=max(0,t); progress=np.minimum(1,elapsed/1.05);height=12.5
 distance=(gr[:,0]*height+elapsed*8.5)%height
 z=height-distance; radius=(.16+distance*.14)*np.sqrt(gr[:,1]); theta=gr[:,2]*math.tau
 xyz=np.column_stack([radius*np.cos(theta),radius*np.sin(theta),z]);xyz[distance>height*progress,2]=-2
 from vtk.util.numpy_support import numpy_to_vtk
 pts.SetData(numpy_to_vtk(xyz,deep=True));pts.Modified();poly.Modified();sand.SetVisibility(True)
 drain=min(.83,max(0,elapsed/15));show(top,True,tr(0,0,18*drain)@scale(1,1,1-drain));show(pile,True,tr(0,0,.25+drain*1.25)@scale(.30+drain*.85,.30+drain*.85,.12+drain*.85))
# dragon: block creature, rounded muzzle, horns, claws, wings, segmented tail
D='285b55';G='438d76';L='73b794';B='c5b578';Y='d6bb78'
def dp(sh,p,s,c,rot=None):return part(dragon,sh,p,s,c,rot)
dp('round',(0,.3,2.3),(2.9,4.2,3.2),G);dp('ball',(0,-1,2.5),(2.35,1.5,2.8),B);dp('round',(0,-.95,4),(1.68,1.7,2.7),G,rx(-19));dp('round',(0,-1.65,5.2),(2.4,2.65,1.75),G);dp('round',(0,-2.89,4.88),(2,1.75,.96),L);dp('round',(0,-2.79,4.49),(1.9,1.55,.39),B)
for x in [-.74,.74]:
 dp('ball',(x,-3.6,5.06),(.25,.17,.19),D);dp('round',(x,-2.99,5.55),(.76,.35,.54),D);dp('ball',(x,-3.16,5.54),(.51,.15,.36),'f4cc60');dp('round',(x,-3.25,5.54),(.115,.07,.31),'1a2930');dp('ball',(x-.07,-3.29,5.65),(.09,.035,.09),'ffffff');dp('cone',(x,-.99,6.19),(.52,.52,1.25),Y,ry(-22 if x<0 else 22));dp('cone',(x*1.38,-.67,5.73),(.6,.5,.85),L,ry(-62 if x<0 else 62))
for z,y in [(4.7,.23),(3.7,1.5),(3.2,2.1)]:dp('cone',(0,y,z),(.58,.74,.88),Y)
for side in [-1,1]:
 for y in [-.9,1.4]:
  dp('round',(side*1.30,y,1.4),(1.05,1.13,2.1),G,ry(side*10));dp('round',(side*1.47,y-.35,.45),(1.32,1.55,.6),D)
  for j in range(3):dp('cone',(side*1.47+(j-1)*.4,y-1.06,.39),(.25,.25,.53),Y,rx(83))
for side,gg in [(-1,wl),(1,wr)]:
 vv=[(0,0,0),(side*2.1,.15,2),(side*5.3,1,2.5),(side*4.1,2,.2),(side*3.4,2.1,.8),(side*2.4,2.65,-.4),(side*1.5,2.45,.35),(side*.55,1.2,-.25)];sh='wing'+str(side);MAP[sh]=mapper(mesh(vv,[[0,1,2,3,4,5,6,7]]));part(gg,sh,(0,0,0),(1,1,1),'719e8f')
 for end in [vv[2],vv[3],vv[5],vv[7]]:gg.append((line([(0,0,0),tuple(np.array(end)*.55+np.array([0,0,.23])),end],D,.11),np.eye(4)))
for i in range(10):
 y=1.9+i*.58;x=math.sin(i*.24)*1.45;z=1.95-.12*i;s=1.5-i*.115;part(tail,'round',(x,y,z),(s,.85,s*.8),G,rz(-12))
 if i%2==0:part(tail,'cone',(x,y,z+s*.45),(.35,.42,.58),Y)
for i in range(3):part(paw,'round',((i-1)*.55,-.20,.2),(.49,1.3,.48),G);part(paw,'cone',((i-1)*.55,-.91,.24),(.24,.24,.51),Y,rx(83))
part(paw,'round',(0,.44,0),(1.95,1.9,.6),D)
def dragonpose(x,y,z,yaw,t,flap=.18,s=1,v=True):
 m=tr(x,y,z)@rz(yaw)@scale(s,s,s);show(dragon,v,m);show(tail,v,m@rz(5*math.sin(t*1.7)));a=flap*math.sin(t*3.8)*45;show(wl,v,m@tr(-1.08,.3,3.1)@ry(a));show(wr,v,m@tr(1.08,.3,3.1)@ry(-a))
hero=Char('e8bc80','df884b','36495f','594136');dad=Char('d6aa72','567f86','41474e','3b4a3f');mom=Char('e3b780','b85d73','584a67','684336');sis=Char('e9c082','d8b54e','58657f','634a34');colors=['b84d54','487ca9','64a975','dcb148','9476bd','df7964','416a77','dd9fca'];skins=['e6b57c','c99062','f0cd91','a56e48','dba074','ac825b'];hairs=['594438','352b2c','6a4c37','262a30','b18c4d','814e32'];crowd=[Char(skins[i%6],colors[i%8],['4e596d','313f52','695746'][i%3],hairs[i%6]) for i in range(18)]
def char(c,x,y,t,yaw=0,walk=0,sz=.73,z=0,afraid=False,arms=None,m=None):
 c.pose(0,0,yaw,walk,t,arms=arms,afraid=afraid);root=tr(x,y,z)@scale(sz,sz,sz)
 if m is not None:root=m@root
 for a in [p[1] for p in c.parts]+[c.shadow]:
  v=a.GetUserMatrix();b=np.array([[v.GetElement(i,j) for j in range(4)] for i in range(4)]);apply(a,root@b)
def people(t,run=False,m=None):
 for i,c in enumerate(crowd):
  row,col=divmod(i,6);x=(col-2.5)*.94;y=.0+row*1.62
  if run:y+=min(4.6-y,t*1.12);x*=max(.28,1-t*.13)
  else:x+=.13*math.sin(t*1.3+i);y+=.13*math.cos(t+i)
  char(c,x,y,t+i*.13,180 if run else [-12,15,25,-20,8,35][col],.75 if run else .18,.58+i%3*.055,afraid=run,m=m)
def family(t,x=0,y=-1,run=False,m=None):
 for c,dx,dy,sz in [(hero,0,0,.65),(mom,-1.08,.36,.9),(dad,1.02,.55,.95),(sis,.68,-.48,.51)]:char(c,x+dx,y+dy,t,180 if run else 0,.85 if run else .18,sz,afraid=run,m=m)
part(bag,'round',(0,0,0),(.55,.33,.62),'397d9b');part(bag,'round',(0,-.18,-.12),(.46,.12,.28),'25566f');part(bag,'round',(0,0,.34),(.23,.11,.12),'e6ba60')
for path in [[(7.75,-2,1.4),(8,-1.9,2.1),(7.85,-1.65,2.6),(7.95,-1.45,3)],[(8,-1.9,2.1),(7.82,-2.25,2.42),(7.7,-2.6,2.67)],[(7.85,-1.65,2.6),(8.1,-1.35,2.34),(8.2,-.96,2.19)],[(7.75,-2,1.4),(7.57,-2.15,.95)]]:crack.append((line(path,'effaff',.07),np.eye(4)))
arm=actor('round',G)
def arm_between(a,b):
 a=np.array(a);b=np.array(b);v=b-a;l=np.linalg.norm(v);zz=v/l;xx=np.cross([0,1,0],zz);xx/=np.linalg.norm(xx);yy=np.cross(zz,xx);m=np.eye(4);m[:3,:3]=np.column_stack([xx,yy,zz]);arm.SetVisibility(True);apply(arm,tr(*((a+b)/2))@m@scale(.85,.85,l+.2))
cam=r.GetActiveCamera();cam.SetClippingRange(.03,180);cam.SetViewAngle(43);cam.SetViewUp(0,0,1);filt=vtk.vtkWindowToImageFilter();filt.SetInput(w);filt.ReadFrontBufferOff();filt.SetInputBufferTypeToRGB();font=ImageFont.truetype('/usr/share/fonts/truetype/lato/Lato-Black.ttf',59);small=ImageFont.truetype('/usr/share/fonts/truetype/lato/Lato-Black.ttf',44)
def lerp(a,b,u):return a+(b-a)*u
def smooth(u):u=max(0,min(1,u));return u*u*(3-2*u)
def scene(t):
 k=next((i for i,s in enumerate(S) if t<s['end']),len(S)-1);dt=t-S[k]['start'];u=min(1,dt/(S[k]['end']-S[k]['start']));q=smooth(u)
 for c in crowd+[hero,mom,dad,sis]:c.pose(0,0,visible=False)
 show(world);show(glass,False);show(outside,False);show(top,False);show(pile,False);show(bell,False);show(bag,False);show(crack,False);show(paw,False);sand.SetVisibility(False);arm.SetVisibility(False);dragonpose(0,0,0,0,t,v=False);cam.SetViewUp(0,0,1);cam.SetViewAngle(43)
 if k==0:
  show(outside);show(glass);show(top);people(t);family(t);dragonpose(12,2,-1.5,-32,t,.15,1.12);cp=(19-3*q,-56+3*q,20+2*q);target=(2.8,0,12.3);cam.SetViewAngle(45)
 elif k==1:
  people(t);family(t,-.3,-2.8+q*.6);show(bag,True,tr(-.3,-2.55+q*.6,.83));cp=(1.3-q*.8,-7.8+q*1.15,3.8);target=(0,-.7,1.5);cam.SetViewAngle(47)
 elif k==2:
  show(outside);angle=180*smooth((u-.12)/.83);m=tr(0,0,12.5)@ry(angle)@tr(0,0,-12.5);show(glass,True,m);show(world,True,m);show(top,True,m);people(0,m=m);family(0,m=m);dragonpose(13,3,-1.5,-35,t,.25,1);cp=(16,-67,24);target=(0,0,12.3);cam.SetViewAngle(49)
 elif k==3:
  people(dt,True);family(dt,0,-2.5+q*4,True);show(bell,True,tr(-2,3.55,4.42)@ry(26*math.sin(dt*12)))
  if u<.28:cp=(-.3,-.2,5.4);target=(-2,3.55,4.4)
  else:cp=(0,-5.9+q*.8,4.6);target=(0,3.4,1.35);cam.SetViewAngle(48)
 elif k==4:
  show(glass);show(outside);show(top);people(t);family(t);dragonpose(11.6,1.2,-1.5,-5+10*q,t,.63,1.30);cp=(17-1*q,-30+2*q,12.5);target=(8.9,0,6);cam.SetViewAngle(48)
 elif k==5:
  people(2.6+dt,True)
  for c,x,y,sz in [(mom,-.8,4.4,.9),(dad,.9,4.3,.95),(sis,.4,3.9,.51)]:char(c,x,y+q*.5,dt,180,.7,sz,afraid=True)
  if u<.4:x=1.3;y=-1.8+u*4.2;char(hero,x,y,dt,180,1,.65,afraid=True);p=(x+.48,y+.06,lerp(.86,.32,smooth(u/.4)))
  else:x=1.3;y=lerp(-.12,-1.68,smooth((u-.4)/.6));char(hero,x,y,dt,0,1,.65,afraid=True);p=(1.74,-1.75,.33)
  show(bag,True,tr(*p)@rx(75*smooth(u/.4)));cp=(3.9-q*.7,-5.3+q*.7,2.8);target=(1.1,-.5,1.25)
 elif k==6:
  char(hero,1.55+q*4.85,-.55,dt,0,.70 if u<.58 else 0,.65,afraid=True,arms=(-35,-45));show(bag,True,tr(1.74,-1.75,.28)@rx(75));falling(dt,.4);cp=(1.55+q*4.85,-1.03,3.0+q*.20);target=(1.55+q*4.85,-.55,1.15);cam.SetViewUp(math.sin(q*.25),0,math.cos(q*.25));cam.SetViewAngle(62)
  if u<.48:
   show(glass);show(outside);show(top);falling(dt,.4);cp=(13,-39,14);target=(0,0,10.5);cam.SetViewAngle(47)
 elif k==7:
  char(hero,6.4,-1.85,dt,0,0,.65,afraid=True,arms=(-56,-38))
  for c,x,sz in [(mom,-.65,.9),(dad,.75,.95),(sis,0,.51)]:char(c,x,5.12,dt,0,0,sz,afraid=True,arms=(-60,-78))
  falling(t-S[6]['start'],1)
  if u<.48:show(glass);show(outside);cp=(13,-42,15);target=(0,0,10.7);cam.SetViewAngle(48)
  elif u<.63:cp=(1.8,2.4,2.9);target=(0,5.12,1.5);cam.SetViewAngle(46)
  else:cp=(3.6,-2.9,2.5);target=(6.4,-1.85,1.1);cam.SetViewAngle(47)
 elif k==8:
  show(glass);show(outside);show(top);falling(t-S[6]['start'],1);char(hero,6.4,-1.85,dt,0,0,.65,afraid=True,arms=(-60,-40));dragonpose(12.5,-.7,-1.5,-38,t,.44,1.1);show(crack,u>.3);px=lerp(11.8,7.15,smooth(u/.65));show(paw,True,tr(px,-1.85,.9)@rz(-90)@scale(1.25,1.25,1.25));arm_between((11.6,-1.1,1.55),(px,-1.85,.9));cp=(10.7,-10.3,5.8);target=(9.1,-1.2,2.8);cam.SetViewAngle(45)
 elif k==9:
  show(glass);show(outside);show(top);show(crack);falling(t-S[6]['start'],1.4);dragonpose(12.6,-.8,-1.5,-35,t,.5,1.12);x=lerp(7.15,10.35,q);z=lerp(.9,4,q);show(paw,True,tr(x,-1.85,z)@rz(-90)@scale(1.25,1.25,1.25));char(hero,x,-2.02,dt,0,0,.65,z+.45,afraid=u<.25,arms=(-30,-30));arm_between((11.6,-1.1,1.55),(x,-1.85,z));cp=(10.8+q*2.4,-11.2+q*1.3,5.9+q*1.7);target=(x,-1.7,2.1+q*2.4);cam.SetViewAngle(45)
 else:
  show(glass);show(outside);falling(t-S[6]['start'],1.4);dragonpose(11.3,1.2,-1.5,-25,t,.1,1.15);show(paw,True,tr(11,-2.5,1.05)@scale(1.25,1.25,1.25));arm_between((10.8,-.15,1.6),(11,-2.5,1.05));char(hero,11,-2.65,dt,0,0,.65,1.5,arms=(-12,-18));char(mom,9.9,-3.3,dt,0,0,.9,-1.33,arms=(-28,-38));char(dad,11.9,-3.3,dt,0,0,.95,-1.33,arms=(-25,-35));char(sis,10.85,-4.1,dt,0,0,.51,-1.33);cp=(16.3+q*2.6,-13.7-q*4,5.1+q*3.1);target=(10.9,-1.2,3.5+q*.5);cam.SetViewAngle(46)
 cam.SetPosition(*cp);cam.SetFocalPoint(*target);w.Render();filt.Modified();filt.Update();im=Image.fromarray(vtk_to_numpy(filt.GetOutput().GetPointData().GetScalars()).reshape(H,W,3)[::-1].copy());d=ImageDraw.Draw(im)
 local=[dict(x) for x in words if S[k]['start']<=x['start']<S[k]['end']];
 if k==2:
  j=next((j for j,x in enumerate(local) if x['word']=='twenty'),None)
  if j is not None and j+1<len(local) and local[j+1]['word']=='four':local[j]['word']='24';local[j]['end']=local[j+1]['end'];local.pop(j+1)
 active=next((i for i,x in enumerate(local) if x['start']<=t<x['end']),None)
 if active is None:active=max(0,sum(x['end']<=t for x in local)-1)
 st=(active//3)*3;group=local[st:st+3];texts=[a['word'].upper() for a in group];f=font;sp=13;ls=[d.textlength(x,font=f) for x in texts]
 if sum(ls)+sp*(len(texts)-1)>W-70:f=small;ls=[d.textlength(x,font=f) for x in texts]
 left=(W-sum(ls)-sp*(len(texts)-1))/2
 for i,(s,l) in enumerate(zip(texts,ls)):d.text((left,H*.775),s,font=f,fill='#ffd55a' if i+st==active else 'white',stroke_width=5,stroke_fill='#15212a',anchor='lm');left+=l+sp
 return im
if __name__=='__main__':
 if '--preview' in sys.argv:
  for i,s in enumerate(S):scene((s['start']+s['end'])/2).save(P/f'preview{i}.jpg',quality=92)
  exit()
 cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',str(P/'visual.mp4')];proc=subprocess.Popen(cmd,stdin=subprocess.PIPE);n=math.ceil(T['duration']*FPS);start=time.time()
 for i in range(n):
  proc.stdin.write(np.asarray(scene(i/FPS)).tobytes())
  if i%90==0:print(i,n,round(time.time()-start,1),flush=True)
 proc.stdin.close();assert proc.wait()==0
